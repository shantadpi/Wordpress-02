<?php
    wp_enqueue_style('style-1',get_stylesheet_uri());
    wp_enqueue_style('style-bootstrap',get_template_directory_uri().'/assets/css/bootstrap.min.css');
    wp_enqueue_script('script-name', get_template_directory_uri().'/assets/js/bootstrap.bundle.min.js', array(), '1.0', true);

    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'post-thumbnails' );

    register_sidebar(array(
        'name'=>'Logo Top Right ',
        'id'=>'ltr',
        'before_widget'  => '',
		'after_widget'   => "",
    ) );
    
    register_sidebar(array(
        'name'=>'Hero Title ',
        'id'=>'h_title',
        'before_widget'  => '',
		'after_widget'   => "",
    ) );
    register_sidebar(array(
        'name'=>'hero card image',
        'id'=>'card_img',
        'before_widget'  => '',
		'after_widget'   => "",
    ) );
    register_sidebar(array(
        'name'=>'Card Body_1',
        'id'=>'card_body_1',
        'before_widget'  => '',
		'after_widget'   => "",
    ) );
    register_sidebar(array(
        'name'=>'Card Body_2',
        'id'=>'card_body_2',
        'before_widget'  => '',
		'after_widget'   => "",
    ) );
    register_sidebar(array(
        'name'=>'Card Body_3',
        'id'=>'card_body_3',
        'before_widget'  => '',
		'after_widget'   => "",
    ) );

    register_nav_menus( array(
        'TM'=>'Primary',

    ) );



?>